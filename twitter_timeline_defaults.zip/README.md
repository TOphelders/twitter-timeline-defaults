# Twitter Timeline Defaults

A simple FireFox extension to remove the new tab home tab for switching between "For You" and "Following" timelines.
Defaults to only showing the Following feed.
